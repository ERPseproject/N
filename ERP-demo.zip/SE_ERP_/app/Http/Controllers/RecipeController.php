<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB as DB;

use App\Recipes;
use App\Pjs;
use DB;
class RecipeController extends Controller
{
    public function index()
    {
        return view('mou.recipes.recipe');
    }
    
    //ใช้ดึง proid จาก pjs
    public static function getPid()
    {
      $conn = mysqli_connect("localhost","root","","erp");
      $query = "SELECT proid FROM `pjs` ";
      $result = mysqli_query($conn, $query);
      if ($result-> num_rows > 0)
      {
        while ($row1 = mysqli_fetch_array($result))
        {
            echo 
          "<option>".$row1['proid']."</option>";
                       
         
        }
        $conn-> close();
      }
    }
    //ใช้ดึงชื่อลูกค้า
    public static function getCus()
    {
      $conn = mysqli_connect("localhost","root","","erp");
      $query = "SELECT name FROM `customers` ";
      $result = mysqli_query($conn, $query);
      if ($result-> num_rows > 0)
      {
        while ($row1 = mysqli_fetch_array($result))
        {
            echo 
          "<option>".$row1['name']."</option>";
                       
         
        }
        $conn-> close();
      }
    }

    // public static function upCus()
    // {
    //   $conn = mysqli_connect("localhost","root","","erp");
    //   $query = "UPDATE pjs SET cname=:'cname' WHERE proid=:'proid' ";
    //   $result = mysqli_query($conn, $query);
        
      
      
    //   $conn-> close();
      
    // }


    //ใช้บันทึกใบเสร็จลง DB รูปภาพลง public/upload/recipe
    public function store(Request $request)
    {
        $recipe = new Recipes();

        $recipe->proid = $request->input('proid');
        $recipe->image = $request->input('image');
        $recipe->date =  $request->input('date');
        $recipe->money = $request->input('money');
       

        if ($request->hasfile('image')){
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension(); //getting img extension
            $fname= $request->file('image')->getClientOriginalName();
            $filename = $fname . '.' . $extension;
            //file in /storage/app/public/uploads
            $request->file('image')->storeAs('public/uploads/recipes/' ,$filename);
            $recipe->image = $filename;
        } else {
            return $request;
            $recipe->image = '';
        }
        $recipe->save();

         $new_p = $request->input('cname');;
         $type = $request->input('type');;
        //check is MOU or Open and cname is  '-' or not
        //ถ้าเป็น Open เข้าไปทำการอัพเดทชื่อใน cname ของ pjs
        //check - กรณี Open มีชื่อผู้บริการอยู่แล้ว
       if ( $type == "Open" and $new_p != "-") {

          $new_id = $recipe->proid;
  
          //$new_p = $request->input('cname');;
          //type Open เท่านั้น ป้องกันติ๊ก id ของ MOU แต่เลือก type = Open ทำให้เกิดการเปลี่ยนชื่อลูกค้า
          DB::table('pjs')->where('proid', $new_id)->where('type', 'Open')->update(['cname' => $new_p]);
  
      }


        
        //DB::table('pjs')->join('recipes', 'pjs.proid', '=', 'recipes.proid')->update(['pjs.cname'=>DB::raw('cname')]);

        // return view('mou.recipes.recipe')->with('success','Data Added');
        return redirect()->back()->with('success','Data Added');

        //ต้องทำบวก money ไปเพิ่มที่ total ของ pjs จากเลข proid ที่ได้ (ใช้ PDO)


    }

}
