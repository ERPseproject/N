@extends('layouts.ProjectandService_app')
  
@section('content')



<script language="javascript">
      function show_table(id) {
        if(id == 'MOU') { // ถ้าเลือก radio button 1 ให้โชว์ table 1 และ ซ่อน table 2
          document.getElementById("a").style.display = "";
          document.getElementById("b").style.display = "";
          document.getElementById("c").style.display = "";
          document.getElementById("d").style.display = "";
          document.getElementById("e").style.display = "";
        } else if(id == 'Open') { // ถ้าเลือก radio button 2 ให้โชว์ table 2 และ ซ่อน table 1
          document.getElementById("a").style.display = "none";
          document.getElementById("b").style.display = "none";
          document.getElementById("c").style.display = "none";
          document.getElementById("d").style.display = "none";
          document.getElementById("e").style.display = "none";
        }
      }
    </script>

 
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
            <!-- <h5>
                <p> <a href="./mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./customer">เพิ่มข้อมูลผู้รับบริการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./search_project">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./search_service">ค้นหาข้อมูลโครงการบริการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./recipe">การบันทึกใบเสร็จ</a><br></p>
            </h5> -->
                </div>



                <div class="col-sm-8 main">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">เพิ่มข้อมูลโครงการพัฒนาวิชาการ</h1>
                      <div class="form-group">
                        <label for="usr">ชื่อโครงการ:</label>
                        <input type="text" class="form-control" id="usr">
                      </div>
                      <div class="form-inline">
                        <label for="sel1">ชื่อผู้รับผิดชอบ(หัวหน้าโครงการ):</label>
                        <select class="form-control" id="sel1">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                          <option>-</option>
                        </select>
                        <label for="sel1">ชื่อผู้รับผิดชอบ:</label>
                        <select class="form-control" id="sel1">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                            <option>-</option>
                        </select>
                        <label for="sel1">ชื่อผู้รับผิดชอบ:</label>
                        <select class="form-control" id="sel1">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                            <option>-</option>
                        </select>
                        <label for="sel1">ชื่อผู้รับผิดชอบ:</label>
                        <select class="form-control" id="sel1">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                            <option>-</option>
                        </select>
                      </div>
                      <br>

                      <div class="form-group">
                        <label for="usr">เลขกำกับโครงการ:</label>
                        <input type="text" class="form-control" id="usr">
                      </div>



                      <div class="radio" >
                        <label><input value="MOU" type="radio" name="optradio" onclick="show_table(this.value);" checked="checked">MOU</label>
                        <label><input value="Open" type="radio" name="optradio" onclick="show_table(this.value);">Open</label>
                      </div><br>
                      <div class="form-group" id='a'>
                        <label for="sel1">ผู้รับบริการ:</label>
                        <select class="form-control" id="customer">
                          <option>นายJack</option>
                          <option>นางRose</option>
                          <option>นางSuzie</option>
                          <option>นางสาวBatman</option>
                        </select>
                      </div>

                      <div class="form-group" id='b'>
                        <label for="pwd">งบประมาณ:</label>
                        <input type="password" class="form-control" id="pwd">
                      </div>

                      <div class="form-group" id='c'>
                        <form action="upload.php" method="post" enctype="multipart/form-data">
                      <b>อัพโหลดไฟล์เอกสาร:</b>
                        <input type="file" name="fileToUpload" id="fileToUpload"><br>
                      </form>
                      </div>

                      <form class="form-inline" action="/action_page.php" id='d'>
                        <div class="form-group">
                          <label for="email">วันเปิดโครงการ:</label>
                          <input type="email" class="form-control" id="email">&nbsp;&nbsp;
                        </div>
                        <div class="form-group">
                          <label for="pwd">วันปิดโครงการ:</label>
                          <input type="password" class="form-control" id="pwd">&nbsp;
                        </div>
                      </form><br>
                      <div class="form-group" id='e'>
                        <label for="pwd">ปีงบประมาณ:</label>
                        <input type="password" class="form-control" id="pwd">
                      </div>

                      <a href="confirm.html"><input type="button" value="submit" class="btn btn-default"></a>
                    </div>
                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
  

    @endsection
    @section('footer')
    
    @endsection

