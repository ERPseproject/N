
  @extends('layouts.Project_app')
@section('content')

  


  
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
                </div>



                <div class="col-sm-8 main">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">
                      <h2 style="text-align: center">ค้นหาข้อมูลโครงการ</h2> <br>
                      <article>
                          <h1 style="font-size : 20px;text-align:center">ชื่อโครงการ/หัวหน้าโครงการ/ปีงบประมาณ</h1>
                          <form>
                            <div style="text-align:center">
                            <input type="text" name="inputsearch" placeholder="ชื่อโครงการ">
                            <input type="text" name="inputsearch" placeholder="หัวหน้าโครงการ">
                            <input type="text" name="inputsearch" placeholder="ปีงบประมาณ">
                            <input type="submit"  value="Search">
                            </div>
                           </form>
                           <div class="card">
                             <h1 style="font-size: 25px">โครงการบ้านนี้มีรัก</h1>
                             <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                             <p>ปีงบประมาณ ปี2017 100ล้าน </p>
                             <p><a href="view"><button type="button">View</button></a><a href="edit"><button>Edit</button></a><button onclick="d()">delete</button></p>
                           </div>
                           <div class="card">
                             <h1 style="font-size: 25px">โครงการรักพรุ่งนี้ยังไม่สาย</h1>
                             <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                             <p>ปีงบประมาณ ปี2018 100ล้าน </p>
                             <p><a href="view"><button type="button">View</button></a><a href="edit"><button>Edit</button></a><button onclick="d()">delete</button></p>
                           </div>
                           <div class="card">
                             <h1 style="font-size: 25px">โครงการรักวันละนิดจิตแจ่มใส</h1>
                             <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                             <p>ปีงบประมาณ ปี2019 100ล้าน </p>
                             <p><a href="view"><button type="button">View</button></a><a href="edit"><button>Edit</button></a><button onclick="d()">delete</button></p>
                           </div>
                           <div class="card">
                             <h1 style="font-size: 25px">โครงการรักวันละนิดจิตแจ่มใส</h1>
                             <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                             <p>ปีงบประมาณ ปี2019 100ล้าน </p>
                             <p><a href="view"><button type="button">View</button></a><a href="edit"><button>Edit</button></a><button onclick="d()">delete</button></p>
                           </div>
                           <div class="card">
                             <h1 style="font-size: 25px">โครงการรักวันละนิดจิตแจ่มใส</h1>
                             <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                             <p>ปีงบประมาณ ปี2019 100ล้าน </p>
                             <p><a href="view"><button type="button">View</button></a><a href="edit"><button>Edit</button></a><button onclick="d()">delete</button></p>
                           </div>
                           <div class="card">
                             <h1 style="font-size: 25px">โครงการรักวันละนิดจิตแจ่มใส</h1>
                             <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                             <p>ปีงบประมาณ ปี2019 100ล้าน </p>
                             <p><a href="view"><button type="button">View</button></a><a href="edit"><button>Edit</button></a><button onclick="d()">delete</button></p>
                           </div>


                  </article>



                    </div>

                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
   
    @endsection
    @section('footer')
    
    @endsection
