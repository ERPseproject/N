<!DOCTYPE html>
<html>
<head>
<title>ปี4</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

</head>
<style>
  header{
    background-color: black;
    padding: 10px;
    text-align: center;
    font-size: 50px;
    color: white;
    height: 200px;
  }
</style>
<body>
  <header>
    <h1 style="font-size : 90px">ปี4</h1>
    <a href="./tarhtml.html"><button type="button" class="btn btn-primary">Home</button></a>
    <a href="./Project_and_service/Project/pe1"><button type="button" class="btn btn-info">ปี1</button></a>
    <a href="./Project_and_service/Project/pe2"><button type="button" class="btn btn-warning">ปี2</button></a>
    <a href="./Project_and_service/Project/pe3"><button type="button" class="btn btn-danger">ปี3</button></a>
    <a href="./Project_and_service/Project/pe4"><button type="button" class="btn btn-info">ปี4</button></a>
  </header>
</body>
