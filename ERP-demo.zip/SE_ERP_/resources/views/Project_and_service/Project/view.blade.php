@extends('layouts.Sapp')
@section('content')



<div class="container-fluid ">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>
        <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
      </h4>
    </div>



    <div class="col-sm-8 main">
      <div class="w3-row w3-padding-64">
        <div class="w3-twothird w3-container">
          <h2 style="text-align:center">รายละเอียดโครงการ</h2> <br>
          <article>
            <table id="customers">
              <tr>
                <th>ชื่อโครงการ</th>
                <th>ผู้รับผิดชอบ</th>
                <th>เลขกำกับ</th>
                <th>MOU/OPEN</th>
                <th>ผู้รับบริการ</th>
                <th>งบประมาณ</th>
                <th>เอกสาร</th>
                <th>วันเปิดโครงการ</th>
                <th>วันปิดโครงการ</th>
                <th>ปีงบประมาณ</th>
                <th>จำนวนเงินรวมรายปี</th>
              </tr>
              <tr>
                <td>โครงการบ้านนี้มีรัก</td>
                <td>นายธีรเจต ทัศนียานนท์</td>
                <td>001</td>
                <td>-</td>
                <td>TOA</td>
                <td>100M</td>
                <td><a href=""><button type="button" class="btn btn-primary">download</button>
                  </a></td>
                <td>20/12/19</td>
                <td>31/12/19</td>
                <td>2019</td>
                <td>-</td>
              </tr>

            </table><br>
            <table id="customers">
              <tr>
                <th>ใบเสร็จ</th>
              </tr>
              <tr>
                <td><a href=""><button type="button" class="btn btn-primary">download</button>
                  </a></td>
              </tr>

            </table>
            <div class="aa">
              <br><a href="tarhtml.html" class="btn btn-danger" style="margin-left:470px;margin-top:300px"> Back</a>

            </div>
          </article>



        </div>

      </div>
    </div>
    <div class="col-sm-2 sidenav"></div>
  </div>
</div>
</div>

@endsection
@section('footer')

@endsection