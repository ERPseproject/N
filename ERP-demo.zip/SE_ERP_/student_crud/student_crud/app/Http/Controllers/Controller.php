<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    // Insert
    public static function getData()
    {
      $conn = mysqli_connect("localhost","root","","erp");
      $sql = "SELECT idhr,name,pos,access_lv,gmail,Address,pass,provider_id from hr";
      $result = $conn-> query($sql);
      if ($result-> num_rows > 0)
      {
        while ($row = $result-> fetch_assoc())
        {
          echo
          "<tr><td>". $row["idhr"]."</td>"
          ."<td>". $row["name"]."</td>"
          ."<td>". $row["pos"]."</td>"
          ."<td>". $row["access_lv"]."</td>"
          ."<td>". $row["gmail"]."</td>"
          ."<td>". $row["Address"]."</td>"
          ."<td>". $row["pass"]."</td>"
          ."<td>". $row["provider_id"]."</td>"
          ."</tr>";
        }
        $conn-> close();
      }
    }
}
