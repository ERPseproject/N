    
   

<?php $__env->startSection('content'); ?>
<script language="javascript">
      function show_table(id) {
        if(id == 'Open') { // ถ้าเลือก radio button 1 ให้โชว์ table 1 และ ซ่อน table 2
          document.getElementById("a").style.display = "";
          document.getElementById("b").style.display = "";
          document.getElementById("c").style.display = "";
          document.getElementById("d").style.display = "";
          document.getElementById("e").style.display = "";
        } else if(id == 'MOU') { // ถ้าเลือก radio button 2 ให้โชว์ table 2 และ ซ่อน table 1
          document.getElementById("a").style.display = "none";
          document.getElementById("b").style.display = "none";
          document.getElementById("c").style.display = "none";
          document.getElementById("d").style.display = "none";
          document.getElementById("e").style.display = "none";
        }
      }
    </script>

        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
            <!-- <h5>
                <p> <a href="./mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./customer">เพิ่มข้อมูลผู้รับบริการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./search_project">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./search_service">ค้นหาข้อมูลโครงการบริการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./recipe">การบันทึกใบเสร็จ</a><br></p>
            </h5> -->
                </div>



                <div class="col-sm-8 main">
                  <div class="w3-row w3-padding-40">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">การบันทึกใบเสร็จ</h1><br>
                      <div class="form-group">
                        <label for="sel1">เลขรหัสโครงการ:</label>
                        <select class="form-control" id="sel1">
                          <option>0000</option>
                          <option>กค1011</option>
                          <option>2222</option>
                          <option>6565</option>
                        </select>
                      </div>
                      <form action="upload.php" method="post" enctype="multipart/form-data">
                    <b>อัพโหลดใบเสร็จ:</b>
                      <input type="file" name="fileToUpload" id="fileToUpload"><br>
                    </form>
                      <div class="form-group">
                        <label for="usr">วันที่ที่ใบเสร็จออก:</label>
                        <input type="text" class="form-control" id="usr">
                      </div>

                      <div class="form-group">
                        <label for="usr">จำนวนเงิน:</label>
                        <input type="text" class="form-control" id="usr">
                      </div>
                      <div class="radio" >
                        <label><input value="MOU" type="radio" name="optradio" onclick="show_table(this.value);" checked="checked">MOU</label>
                        <label><input value="Open" type="radio" name="optradio" onclick="show_table(this.value);">Open</label>
                      </div>
                      <h3 class="w3-text-teal" id='a' style="display:none;">เพิ่มข้อมูลผู้รับบริการ</h3>



                      <div class="form-group" id='b' style="display:none;">
                        <label for="sel1">ผู้รับบริการ:</label>
                        <select class="form-control" id="customer">
                          <option>นายJack</option>
                          <option>นางRose</option>
                          <option>นางSuzie</option>
                          <option>นางสาวBatman</option>
                        </select>
                      </div>
                      <a href="confirm.html"><input type="button" value="submit" class="btn btn-default"></a>

                    </div>
                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer'); ?>
  
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ProjectandService_app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>