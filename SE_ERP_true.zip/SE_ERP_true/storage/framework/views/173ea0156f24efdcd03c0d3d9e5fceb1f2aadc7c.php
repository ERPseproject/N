<?php $__env->startSection('content'); ?>

            <div class="container-fluid text-center">
                <div class="row content">
                    <div class="col-sm-2 sidenav">
                       <h5> <p><a href="./back_varasarn">กรอกข้อมูลวารสาร</a></p></h5>
                       <h5> <p><a href="./academic">กรอกข้อมูลประชุมวิชาการ</a></p></h5>
                       <h5> <p><a href="./back_show">แสดงวารสาร</a></p></h5>
                       <h5> <p><a href="./back_show2">แสดงการประชุมวิชาการ</a></p></h5>
                    </div>
                    <div class="col-sm-8 main">
                        <h1>วารสาร</h1>
                        <br>
                        <p>ชื่อผู้รับผิดชอบ</p>
                        <select name="departcity" id="departcity" onchange="dispterminal(this.value,'departterminal')"
                            class="form-control-search">
                            <option value="">--กรุณาเลือก--</option>
                            <option value="Professor A">Firstname Lastname</option>
                            <option value="Professor B">Firstname Lastname</option>
                            <option value="Professor C">Firstname Lastname</option>
                            <option value="Professor D">Firstname Lastname</option>
                        </select>
                        <br>
                        <p>ปี ค.ศ.</p>
                        <div>
                            <input class="form-control-search">
                        </div>
                        <br>
                        <p>ชื่อวารสาร</p>
                        <div>
                            <input class="form-control-search">
                        </div>

                        <br>

                        <p>Vol.</p>
                        <div>
                            <input class="form-control-search">
                        </div>

                        <br>

                        <p>No.</p>
                        <div>
                            <input class="form-control-search">
                        </div>

                        <br>

                        <p>Page</p>
                        <div>
                            <input class="form-control-search">
                        </div>

                        <br>

                        <p>upload paper</p>
                        <div>
                            <input type="file" value="เลือกไฟล์" class="form-control-search">
                        </div>

                        <br>
                        <input type="submit" value="ยืนยันการส่งข้อมูล">
                    </div>
                    <div class="col-sm-2 sidenav"></div>
                </div>
            </div>
            <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer'); ?>
  
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Varasan_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_\resources\views/Varasarn/index.blade.php ENDPATH**/ ?>