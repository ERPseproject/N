<title>แสดงข้อมูลโครงการ</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>
    <?php $__env->startSection('content'); ?>




    <div class="main">
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="/moufirst/">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/recipe">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                    <div class="w3-row w3-padding-64">
                        <div class="w3-twothird w3-container">
                         <h2 >ข้อมูลโครงการ</h2>
                         <br>
                         <div> 
                                <a href="<?php echo e(url('/mou/mouIn')); ?>" class="btn btn-success"> เพิ่มข้อมูลโครงการ</a>
                                <br>
                                <br>
                            
                         </div>
                         <table class="table table-bordered table-striped">
                            <tr>
                                <th>ชื่อโครงการ</th>
                                <th>หัวหน้าโครงการ</th>
                                <th>ผู้รับผิดชอบคนที่ 2</th>
                                <th>ผู้รับผิดชอบคนที่ 3</th>
                                <th>ผู้รับผิดชอบคนที่ 4</th>
                                <th>เลขรหัสกำกับโครงการ</th>
                                <th>ชนิดโครงการ</th>
                                <th>ชื่อผู้รับบริการ</th>
                                <th>งบประมาณ</th>
                                <th>ไฟล์ pdf </th>
                                <th>วันเปิดโครงการ</th>
                                <th>วันปิดโครงการ</th>
                                <th>ปีงบประมาณ</th>
                                <th>รายรับร่วมปี</th>
                                
                            </tr>
                            
                             <?php $__currentLoopData = $pjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                             
                                <td><?php echo e($row['name']); ?></td>
                                <td><?php echo e($row['leader']); ?></td>
                                <td><?php echo e($row['mem1']); ?></td>
                                <td><?php echo e($row['mem2']); ?></td>
                                <td><?php echo e($row['mem3']); ?></td>
                                <td><?php echo e($row['proid']); ?></td>
                                <td><?php echo e($row['type']); ?></td>
                                <td><?php echo e($row['cname']); ?></td>
                                <td><?php echo e($row['budget']); ?></td>

                                <td><a href="<?php echo e(asset('storage/uploads/pdf/'.$row['fname'])); ?>"> <?php echo e($row['fname']); ?> </a></td>
                                
                                
                                <td> <?php echo e($row['opend'] ? \Carbon\Carbon::parse($row['opend'])->format('d/m/Y') : null); ?></td>
                                <td> <?php echo e($row['closed'] ? \Carbon\Carbon::parse($row['closed'])->format('d/m/Y') : null); ?></td>
                               
                                <td><?php echo e($row['year']); ?></td>
                                <td><?php echo e($row['total']); ?></td>
                               
                             
                                <td><a href="<?php echo e(action('PjsController@edit', $row['id'])); ?>" class='btn btn-primary'>แก้ไข</a></td>
                                <form method="post" class="delete_form" action="<?php echo e(action('PjsController@destroy', $row['id'])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="DELETE" />
                                <td><button type="submit" class="btn btn-danger">ยกเลิก</button></form></td> 
                                
                                </form>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </table>  
                                   


                        </div>
                    </div>
                    </div>
                    <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
        <script type="text/javascript">
        $(document).ready(function(){
            $('.delete_form').on('submit', function(){
                if(confirm("คุณต้องการยกเลิกการเพิ่มข้อมูลโครงการใช่หรือไม่ ?"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            });
        });
        </script>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/mou/mouIn/showmin.blade.php ENDPATH**/ ?>