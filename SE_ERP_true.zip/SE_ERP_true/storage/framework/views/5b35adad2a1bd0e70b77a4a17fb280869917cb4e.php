<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>


<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    
    <!-- datetime picker -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    



</head>


<?php $__env->startSection('content'); ?>



    
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="/moufirst/">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/recipe">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                  <div class="w3-row w3-padding-40">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">แก้ไขข้อมูลการบันทึกใบเสร็จ</h1><br>
                      <div class="form-group">


                         <form method="post" action="<?php echo e(action('RecipeController@update', $id)); ?>" enctype="multipart/form-data" onSubmit="JavaScript:return fncSubmit();">
                        <?php echo e(csrf_field()); ?>


                        <!-- ดึงจากดาต้าเบสโครงการ -->
                        <label >เลขรหัสกำกับโครงการ :</label>
                        <select class="form-control" name="proid" value="<?php echo e($recipes->proid); ?>">
                        <option ><?php echo e($recipes->proid); ?></option>
                        <?php $__currentLoopData = $pjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option> <?php echo e($pjs->proid); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
                        </select>
                      </div>
                    <b>อัพโหลดใบเสร็จ:</b>
                      <input type="file" name="image" class="file-input" id="file" accept="image/*" onchange="return fileValidation()">
                      <!-- Image preview -->
                       <br><br>   
                      <a height="100" width="80" id="2" data-toggle="modal" data-target="#myModal" > คลิ๊กเพื่อดูรูปภาพ </a>
                       <div id="myModal" class="modal fade" role="dialog">
                          <div class="modal-dialog">
                             <div class="modal-content">
                               <div class="modal-body">
                                  <div id="imagePreview" ></div> 
                                    </div>
                                       <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                  </div>
                              </div>
                         </div>
                      </div>
                      <br>
                      <br>


                      <div class="form-group">
                        <label >วันที่ที่ใบเสร็จออก:</label>
                        <input type="text" id="datepicker" name="date" value="<?php echo e(date('d/m/Y', strtotime($recipes->date))); ?>">
                      </div>

                      <div class="form-group">
                        <label>จำนวนเงิน:</label>
                        <input type="text" class="form-control" name="money" onKeyPress="CheckNum()" id="money"
                        value="<?php echo e($recipes->money); ?>">
                        <input type="hidden" class="form-control" name="oldm"
                        value="<?php echo e($recipes->money); ?>">
                      </div>

                      <!-- <div class="radio" >
                        <label><input value="MOU" type="radio" name="type" onclick="show_table(this.value);" checked="checked">MOU</label>
                        <label><input value="Open" type="radio" name="type" onclick="show_table(this.value);">Open</label>
                      </div> -->

            
                      
                      <a href="<?php echo e(url('/recipe/show')); ?>" class="btn btn-success">ยกเลิก</a> <input type="submit" value="ยืนยัน" class="btn btn-default">
                      <input type="hidden" name="_method" value="PATCH" />
                      </form>

                      <!-- <?php if(count($errors)>0): ?>
                      <div class="alert alert-danger">
                          <ul>
                            <?php $__currentLoopData = $errors->all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>

                      <?php endif; ?>
                      <?php if( \Session::has('success')): ?>
                      <div class="alert alert-success">
                        <p><?php echo e(\Session::get('success')); ?></p>
                      </div>
                      <?php endif; ?> -->
                    </div>
                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    

        <script>
    $( function() {
      $( "#datepicker" ).datepicker({
        dateFormat: 'dd/mm/yy',
        changeMonth: false,
        changeYear: true,       
      });
    } );
    </script>
    
    <script>
      function fileValidation(){
          var fileInput = document.getElementById('file');
          var filePath = fileInput.value;
          var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
          if(!allowedExtensions.exec(filePath)){
              alert('อัพโหลดได้เฉพาะไฟล์นามสกุล .jpeg/.jpg/.png/.gif เท่านั้น');
              fileInput.value = '';
              return false;
          }else{
              //Image preview
              if (fileInput.files && fileInput.files[0]) {
                  var reader = new FileReader();
                  reader.onload = function(e) {
                      document.getElementById('imagePreview').innerHTML = '<img class="img-responsive" src="'+e.target.result+'"/>';
                  };
                  reader.readAsDataURL(fileInput.files[0]);
              }
          }
      }
    </script>

    <!-- พิมพ์ได้เฉพาะตัวเลข -->
    <script language="javascript">
      function CheckNum(){
       if (event.keyCode < 48 || event.keyCode > 57){
          event.returnValue = false;
        }
      }
      </script>

    <script type="text/javascript">
    function fncSubmit()
    {
      if(document.getElementById('file').value == "")
      {
            alert('ยังไม่ได้เลือกไฟล์');
            return false;
      }
      if($("#datepicker").datepicker("getDate") === null)
      {
            alert("ยังไม่ได้เลือกวันที่ออกใบเสร็จ");
            return false;
      }
      if(document.getElementById('money').value == "")
      {
            alert('ยังไม่ได้กรอกจำนวนเงิน');
            return false;
      }
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/mou/recipes/edit.blade.php ENDPATH**/ ?>