<?php $__env->startSection('content'); ?>
<script type="text/javascript">
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';

    if (exist) {
        alert(msg);
    }

    function preventBack() {
        window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function() {
        null
    };
</script>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">


                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="col-md-8 offset-md-4">


                             
                                <p>Login Domain @ku.th</p>

                                <a href="<?php echo e(route('login.provider', 'google')); ?>" class="btn btn-primary"><?php echo e(__('Google Login')); ?></a>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_\resources\views/auth/login.blade.php ENDPATH**/ ?>