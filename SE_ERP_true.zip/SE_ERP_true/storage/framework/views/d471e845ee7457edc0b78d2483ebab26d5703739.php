<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
 
    </style>
    <head>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
<?php $__env->startSection('content'); ?>


  <div class="container-fluid">
  <div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="data">Users</a></li>
    <li><a href="pjs_data"></a></li>
    <li><a href="#">JavaScript</a></li>
  </ul>
</div> 
<br><br><br><br>
	<div class="row">
        <div class="col-md-12">
         
          <table class="table table-bordered table-striped">
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Leader</th>
              <th>Member1</th>
              <th>Member2</th>
              <th>Member3</th>
              <th>Type</th>
            </tr>
            <?php $__currentLoopData = $pjss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($row['id']); ?></td> 
              <td><?php echo e($row['name']); ?></td> 
              <td><?php echo e($row['leader']); ?></td>
              <td><?php echo e($row['mem1']); ?></td> 
              <td><?php echo e($row['mem2']); ?></td> 
              <td><?php echo e($row['mem3']); ?></td>
              <td><?php echo e($row['type']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
            
        </div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/db/pjs_data.blade.php ENDPATH**/ ?>