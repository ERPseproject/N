<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>


<head>
    <title>แสดงข้อมูลใบเสร็จ</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


</head>
<?php $__env->startSection('content'); ?>
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="/moufirst/">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/recipe">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                    <div class="w3-row w3-padding-64">
                        <div class="w3-twothird w3-container">
                         <h2 >ข้อมูลการบันทึกใบเสร็จ</h2>
                         <br>
                         <div> 
                                <a href="<?php echo e(url('/recipe')); ?>" class="btn btn-success"> การบันทึกใบเสร็จ</a>
                                <br>
                                <br>
                            
                         </div>
                         <table class="table table-bordered table-striped">
                            <tr>
                                <th>เลขรหัสกำกับโครงการ</th>
                                <th>ใบเสร็จ</th>
                                <th>วันที่ใบเสร็จออก</th>
                                <th>จำนวนเงิน</th>
                                <th>แก้ไขข้อมูล</th>
                                <th>ลบข้อมูล(หักเงินออกจากเงินรายรับร่วมปีของโครงการด้วย)</th>
                                
                            </tr>
                        
                             <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                <td><?php echo e($row['proid']); ?></td>
                                <!-- จัดการรูป -->
                                <script>
                                $(document).ready(function () {
                                        $('#myModal').on('show.bs.modal', function (e) {
                                            var image = $(e.relatedTarget).attr('src');
                                            $(".img-responsive").attr("src", image);
                                        });
                                });
                                </script>
                                <td>
                                <img height="100" width="80" id="2" data-toggle="modal" data-target="#myModal" src="<?php echo e(asset('storage/uploads/recipes/'.$row['image'])); ?>" alt='Text dollar code part one.' />
                                <div id="myModal" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <img class="img-responsive" src="" />
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </td>
            
                                 
                                <td> <?php echo e(\Carbon\Carbon::parse($row['date'])->format('d/m/Y')); ?></td>
                                <td><?php echo e($row['money']); ?></td>
                                <td><a href="<?php echo e(action('RecipeController@edit', $row['id'])); ?>" class='btn btn-primary'>แก้ไข</a></td>
                                <form method="post" class="delete_form" action="<?php echo e(action('RecipeController@destroy', $row['id'])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="DELETE" />
                                <td><button type="submit" class="btn btn-danger">ลบข้อมูล</button></form> </form></td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         </table>           


                        </div>
                    </div>
                    </div>
                    <div class="col-sm-2 sidenav"></div>
            </div>
        
        <script type="text/javascript">
        $(document).ready(function(){
            $('.delete_form').on('submit', function(){
                if(confirm("คุณต้องการลบข้อมูลหรือไม่ ?"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            });
        });
        </script>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/mou/recipes/showrec.blade.php ENDPATH**/ ?>