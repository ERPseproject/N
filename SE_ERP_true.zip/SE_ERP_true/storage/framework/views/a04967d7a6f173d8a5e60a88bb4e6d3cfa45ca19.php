<style media="screen">
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
 
 
    </style>
    <head>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
<?php $__env->startSection('content'); ?>

 
  
 
<br><br><br><br>
<div class="container fluid">
	<div class="row">
  <div class="col-md-6">
  </div>
  <div class="col-md-4" >
    <form action="/datasearch" method="get">
    <div class="input-group">
      <input type="search" name="search" class="form-control ">
      <span class="input-group-prepend">
        <button type="submit" class="btn btn-primary">search</button>

      </span>
    </div>
  </form>
  </div>
        <div class="col-md-12">
         
          <table class="table table-bordered table-striped">
            <tr>
              
              <th>ชือ</th>
              <th>อีเมล</th>
              <th>แก้ไขข้อมูล</th>
              <th>ลบข้อมูล</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($row['name']); ?></td> 
              <td><?php echo e($row['email']); ?></td>
              <td><a href="" class='btn btn-primary'>แก้ไข</a></td>
                                <form method="post" class="delete_form" action="">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="DELETE" />
                                <td><button type="submit" class="btn btn-danger">ลบข้อมูล</button></form> </form></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
            
        </div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/db/data.blade.php ENDPATH**/ ?>