<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>ERP</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" ></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
        
    body
 {
 height: auto;
 margin:  0;
 padding: 0;
 }

 footer
 {
   background-color: #8B0000;
   color: white;
   padding: 15px;
   bottom: 0;
   margin-bottom: 0%;
   width: 100%;
   position: fixed;

 }

</style>
    <!-- datetime picker -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>

<body>
<div id="app">
<nav class="navbar navbar-expand-md navbar-dark navbar-laravel" style="background-color:#800000;">
<div class="container-fluid">
               
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>"><img src="pic/Gears-PNG-Clipart.png" width="50" height="50">ERP</a>
                <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button> -->

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                    <li class="active"><a href="./home">Home</a></li>
                    
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        
                        <?php else: ?>
                            <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php if(auth()->user()->avatar): ?>
                                <img src="<?php echo e(auth()->user()->avatar); ?>" alt="avatar" width="40" height="40" style="margin-right: 10px;">
                                <?php endif; ?>
                                <?php echo e(auth()->user()->name); ?>

                            </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
            
        </main>
        <footer class="container-fluid text-center">
        <?php echo $__env->yieldContent('footer'); ?>
        <h6>KU SRC</h6>
    </footer>
    </div>
</body>

</html>
<?php /**PATH D:\SE_ERP_true\resources\views/layouts/app.blade.php ENDPATH**/ ?>