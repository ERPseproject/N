<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>
    <head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<?php $__env->startSection('content'); ?>






    

    <div class="main">
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="/moufirst/">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/recipe">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">ระบบโครงการพัฒนาวิชาการและบริการ</h1> <br>

                      <div class="list-group">
                        <ul>
                        <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a></li><br>
                        <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a></li><br>
                        <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a></li><br>
                        <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="#">ค้นหาข้อมูลโครงการบริการ</a></li><br>
                        <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="/recipe">การบันทึกใบเสร็จ</a></li><br>
                      </ul>

                      </div>

                    </div>

                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/mou/moufirst.blade.php ENDPATH**/ ?>