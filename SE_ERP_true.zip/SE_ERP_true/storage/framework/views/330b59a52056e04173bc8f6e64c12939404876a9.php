<?php $__env->startSection('content'); ?>

<div class="container-fluid ">
    <div class="row content">
        <div class="col-sm-2 sidenav">
          
            <h5>
                <p> <a href="./mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./customer">เพิ่มข้อมูลผู้รับบริการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./search_project">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./search_service">ค้นหาข้อมูลโครงการบริการ</a><br></p>
            </h5>
            <h5>
                <p><a href="./recipe">การบันทึกใบเสร็จ</a><br></p>
            </h5>
        </div>



        <div class="col-sm-8 main">
            <div class="w3-row w3-padding-64">
                <div class="w3-twothird w3-container">
                    <h1 class="w3-text-teal">ระบบโครงการพัฒนาวิชาการและบริการ</h1> <br>

                    <div class="list-group">
                        <ul>
                            <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="./mouIn">เพิ่มโครงการพัฒนาวิชาการ</a></li><br>
                            <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="./customer">เพิ่มข้อมูลผู้รับบริการ</a></li><br>
                            <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="./search_project">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a></li><br>
                            <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="./search_service">ค้นหาข้อมูลโครงการบริการ</a></li><br>
                            <li><a class="w3-bar-item w3-button w3-hover-black" class="list-group-item" href="./recipe">การบันทึกใบเสร็จ</a></li><br>
                        </ul>

                    </div>

                </div>

            </div>
        </div>
        <div class="col-sm-2 sidenav"></div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ProjectandService_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/Project_and_service/moufirst.blade.php ENDPATH**/ ?>