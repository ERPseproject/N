<?php $__env->startSection('content'); ?>
<script type="text/javascript">
    // var msg = '<?php echo e(Session::get('alert')); ?>';
    // var exist = '<?php echo e(Session::has('alert')); ?>';
    // if (exist) {
    //     alert(msg);
    // }
    function preventBack() {
        window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function() {
        null
    };
</script>


<div class="container text-center" >
<p style="font-size:200px">Welcome</p>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" >
                <div class="card-body">
                    <br>
                    <br>
                    <br>
                    <h2><p>Login Domain @ku.th</p></h2>

                    <a href="<?php echo e(route('login.provider', 'google')); ?>" class="btn btn-primary"><?php echo e(__('Google Login')); ?></a>

                        <?php if(\Session::has('alert')): ?>
                            <div class="alert alert-danger">
                                <p><?php echo e(\Session::get('alert')); ?></p>
                            </div>
                        <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/auth/login.blade.php ENDPATH**/ ?>