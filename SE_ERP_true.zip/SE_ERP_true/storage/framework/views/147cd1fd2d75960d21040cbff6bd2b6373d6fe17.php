<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
 
    </style>
<?php $__env->startSection('content'); ?>


  <div class="container">
	<div class="row">
        <div class="col-md-9">

            <div id="custom-search-input">

            <!-- <form action="select_std.php" method="get"> -->
              <!-- <select class="form-control" name="mj">
                <option value="./admin" selected="./admin">Human Resources</option>
                <option value="./admin"><a href="./admin">Room</a></option>
                <li><a href="#">JavaScript</a></li>
              </select> -->

              <div class="container">

            <div class="dropdown">
              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Databases
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
                <li><a href="./bill_db">Bill</a></li>
                <li><a href="#">Customers</a></li>
                <li><a href="#">Human Resources</a></li>
                <li><a href="#">Machine</a></li>
                <li><a href="#">Project & MOU</a></li>
                <li><a href="#">Research</a></li>
                <li><a href="#">Room</a></li>
              </ul>
            </div>

                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="ป้อนรหัส หรือ ชื่อนิสิต" name="Search">
                    <span class="input-group-btn">
                      <!-- <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="btnGetJson" id="btnGetJson">search</button> -->
                        <button class="btn btn-info btn-lg" type="submit">
                            ...<i class="icon-search"></i>
                        </button>
                    </span>

                </div>
			        </form>
            </div>
        </div>
	</div>
</div>

<div class="container">
  <table class="table table-bordered">
    <br>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Position</th>
        <th>User's Access Level</th>
        <th>Gmail</th>
        <th>Address</th>
        <!-- <th>pass</th>
        <th>provider_id</th> -->
      </tr>
    </thead>
 
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/db/hr.blade.php ENDPATH**/ ?>