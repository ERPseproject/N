<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>

<head>
    <title>การบันทึกใบเสร็จ</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


   

</head>


<?php $__env->startSection('content'); ?>
  


 
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="/moufirst/">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/recipe">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                  <div class="w3-row w3-padding-40">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">การบันทึกใบเสร็จ</h1><br>
                      <div class="form-group">


                         <form method="post" action="<?php echo e(route('addimage')); ?>" enctype="multipart/form-data" onSubmit="JavaScript:return fncSubmit();">
                        <?php echo e(csrf_field()); ?>


                        <!-- ดึงจากดาต้าเบสโครงการ -->
                        <label >เลขรหัสกำกับโครงการ:</label>
                        <select class="form-control" name="proid">
                        
                        <?php $__currentLoopData = $pjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option> <?php echo e($pjs->proid); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
                        </select>
                      </div>
                    <b>อัพโหลดใบเสร็จ:</b>
                    <br>
                    <br>
                      <input type="file" name="image"  id="file" accept="image/*" onchange="return fileValidation()">
                      <!-- Image preview -->

                      <br>
                     
                          
                      <a height="100" width="80" id="2" data-toggle="modal" data-target="#myModal" > คลิ๊กเพื่อดูรูปภาพ </a>
                       <div id="myModal" class="modal fade" role="dialog">
                          <div class="modal-dialog">
                             <div class="modal-content">
                               <div class="modal-body">
                                  <div id="imagePreview" ></div> 
                                    </div>
                                       <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                  </div>
                              </div>
                         </div>
                      </div>
                                
                      

                      
                      <br><br>

                      
                      <div class="form-group">
                        <label >วันที่ที่ใบเสร็จออก:</label>
                        <input type="text" id="datepicker" name="date">
                      </div>

                      <div class="form-group">
                        <label>จำนวนเงิน:</label>
                        <input type="text" class="form-control" name="money" onKeyPress="CheckNum()" id="money">
                      </div>

                      <div class="radio" >
                        <label><input value="MOU" type="radio" name="type" onclick="show_table(this.value);" checked="checked">MOU</label>
                        <label><input value="Open" type="radio" name="type" onclick="show_table(this.value);">Open</label>
                      </div>

                      <!-- ส่วนบริการเพิ่มในโครงการ db-->
                      <h3 class="w3-text-teal" id='a' style="display:none;">เพิ่มข้อมูลผู้รับบริการ(สำหรับ Open กรณียังไม่ได้เพิ่มผู้รับบริการ)</h3>
                      <div class="form-group" id='b' style="display:none;">
                        <label >ผู้รับบริการ:</label>
                        <select class="form-control" name="cname"> 
                        <option >-</option>
                         
                        <?php $__currentLoopData = $cus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option> <?php echo e($cus->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      
                      <a href="<?php echo e(url('/recipe/show')); ?>" class="btn btn-success">ดูข้อมูลการบันทึกใบเสร็จ</a> <input type="submit" value="ยืนยัน" class="btn btn-default">
                      </form>

                     
                    </div>
                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>

            
            <script>
    $( function() {
      $( "#datepicker" ).datepicker({
        dateFormat: 'dd/mm/yy',
        changeMonth: false,
        changeYear: true,       
      });
    } );
    </script>
    
    <script>
      function fileValidation(){
          var fileInput = document.getElementById('file');
          var filePath = fileInput.value;
          var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
          if(!allowedExtensions.exec(filePath)){
              alert('อัพโหลดได้เฉพาะไฟล์นามสกุล .jpeg/.jpg/.png เท่านั้น');
              fileInput.value = '';
              return false;
          }else{
              //Image preview
              if (fileInput.files && fileInput.files[0]) {
                  var reader = new FileReader();
                  reader.onload = function(e) {
                      document.getElementById('imagePreview').innerHTML = '<img  class="img-responsive" src="'+e.target.result+'"/>';
                  };
                  reader.readAsDataURL(fileInput.files[0]);
              }
          }
      }
    </script>

    <!-- พิมพ์ได้เฉพาะตัวเลข -->
    <script language="javascript">
      function CheckNum(){
       if (event.keyCode < 48 || event.keyCode > 57){
          event.returnValue = false;
        }
      }
      </script>

    <script type="text/javascript">
    function fncSubmit()
    {
      if(document.getElementById('file').value == "")
      {
            alert('ยังไม่ได้เลือกไฟล์');
            return false;
      }
      if($("#datepicker").datepicker("getDate") === null)
      {
            alert("ยังไม่ได้เลือกวันที่ออกใบเสร็จ");
            return false;
      }
      if(document.getElementById('money').value == "")
      {
            alert('ยังไม่ได้กรอกจำนวนเงิน');
            return false;
      }
    }
    </script>

    



    <script language="javascript">
      function show_table(id) {
        if(id == 'Open') { // ถ้าเลือก radio button 1 ให้โชว์ table 1 และ ซ่อน table 2
          document.getElementById("a").style.display = "";
          document.getElementById("b").style.display = "";
          document.getElementById("c").style.display = "";
          document.getElementById("d").style.display = "";
          document.getElementById("e").style.display = "";
        } else if(id == 'MOU') { // ถ้าเลือก radio button 2 ให้โชว์ table 2 และ ซ่อน table 1
          document.getElementById("a").style.display = "none";
          document.getElementById("b").style.display = "none";
          document.getElementById("c").style.display = "none";
          document.getElementById("d").style.display = "none";
          document.getElementById("e").style.display = "none";
        }
      }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/mou/recipes/recipe.blade.php ENDPATH**/ ?>