<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>

    <head>
<title>เพิ่มข้อมูลผู้รับบริการ</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>

<?php $__env->startSection('content'); ?>


  
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="/moufirst/">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/mouIn">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/mou/customer">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="/recipe">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">

                      
                      <form method="post" action="<?php echo e(url('mou')); ?>" onSubmit="JavaScript:return fncSubmit();">
                        <?php echo e(csrf_field()); ?>

                      <h1 class="w3-text-teal">เพิ่มข้อมูลผู้รับบริการ</h1>
                      <div class="form-group">
                        <label >ชื่อผู้รับบริการ:</label>
                        <input name="name" type="text" class="form-control" id="name">
                      </div>
                      <div class="form-group">
                        <label for=>ที่อยู่:</label>
                        <input name="address" type="text" class="form-control" id="address">
                      </div>

                      <div class="form-group">
                        <label >เลขประจำตัวผู้เสียภาษี:</label>
                        <input name="tax_id" type="text" class="form-control" onKeyPress="CheckNum()" id="tax">
                      </div>

                      <div class="form-group">
                        <label >สถานภาพ:</label>
                        <select class="form-control" name="status">
                          <option>ราชการ</option>
                          <option>เอกชน</option>
                          <option>รัฐวิสาหกิจ</option>
                          <option>องค์การมหาชน</option>
                        </select>
                      </div>

                      <a href="<?php echo e(url('/mou/customer/show')); ?>" class="btn btn-success">ดูข้อมูลผู้รับบริการ</a> <input type="submit" value="ตกลง" class="btn btn-default">
                       </form>
<!-- 
                       <?php if(count($errors)>0): ?>
                      <div class="alert alert-danger">
                          <ul>
                            <?php $__currentLoopData = $errors->all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div> -->
<!-- 
                      <?php endif; ?>
                      <?php if( \Session::has('success')): ?>
                      <div class="alert alert-success">
                        <p><?php echo e(\Session::get('success')); ?></p>
                      </div>
                      <?php endif; ?> -->
                      </div>
                </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    
 

<script type="text/javascript">
    function fncSubmit()
    {
      if(document.getElementById('name').value == "")
      {
            alert('ยังไม่ได้กรอกชื่อผู้รับบริการ');
            return false;
      }
      if(document.getElementById('address').value == "")
      {
            alert('ยังไม่ได้กรอกที่อยู่');
            return false;
      }
      if(document.getElementById('tax').value == "")
      {
            alert('ยังไม่ได้กรอกเลขประจำตัวผู้เสียภาษี');
            return false;
      }



    }
</script>
 

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/mou/customers/createcus.blade.php ENDPATH**/ ?>