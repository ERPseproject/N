<style>
    .main {
        /* background-color: #8B0000; */
        padding-top: 0%;
        padding-bottom: 5%;
    }
</style>
<?php $__env->startSection('content'); ?>
<script type="text/javascript">
 

  

    //////////////////////////////////
    function preventBack() {
        window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function() {
        null
    };
</script>
<!-- main menu -->
<div class="main">

    <div class="container-fluid text-center">
       
        
            <div class="container-fluid text-center">
        <p style="font-size:100px">Welcome</p>
        <?php if(auth()->user()): ?>
        <img src="<?php echo e(auth()->user()->avatar); ?>" alt="avatar" width="150" height="150" style="margin-right: 10px;"><br><br>
        <?php endif; ?>
        <h2><?php echo e(auth()->user()->name); ?>

            <h2>
                <br><br><br>
                <a href="home" class="btn btn-primary"><h1>เข้าสู่ระบบ</h1></a>
        
       
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SE_ERP_true\resources\views/Home/complete-login.blade.php ENDPATH**/ ?>