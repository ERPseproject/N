<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dbController extends Controller
{
    public static function getData()
    {
      $conn = mysqli_connect("localhost","root","","erp");
      $sql = "SELECT idhr,Name,Pos,Access_Lv,Gmail,Address from hr";
      $result = $conn-> query($sql);
      if ($result-> num_rows > 0)
      {
        while ($row = $result-> fetch_assoc())
        {
          echo
          "<tr><td>". $row["idhr"]."</td>"
          ."<td>". $row["Name"]."</td>"
          ."<td>". $row["Pos"]."</td>"
          ."<td>". $row["Access_Lv"]."</td>"
          ."<td>". $row["Gmail"]."</td>"
          ."<td>". $row["Address"]."</td>"
          
          
          ."</tr>";
        }
        $conn-> close();
      }
    }
}
