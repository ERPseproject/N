<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pjs;
class DatapjsController extends Controller
{
public function index()
  {
    $pjss = Pjs::all()->toArray();
    return view('db.pjs_data', compact('pjss'));
  }
}
