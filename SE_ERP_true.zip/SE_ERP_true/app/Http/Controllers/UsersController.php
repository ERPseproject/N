<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;

class UsersController extends Controller
{
  public function index()
  {
    $users = User::all()->toArray();
    return view('db.data', compact('users'));
  }
  //  public function index(Request $request)
  //  {
  //     $this->validate($request,['users'=> 'required' ,]);
  //         $users = User::all()->toArray();
  //   return view('db.data', compact('users'));
      
  //  }

}
