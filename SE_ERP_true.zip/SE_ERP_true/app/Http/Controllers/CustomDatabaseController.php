<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\User;
class CustomDatabaseController extends Controller
{
    public function index()
    {
        // $users=DB::table('users')->get();
        // return view('db.data')->with('users',$users);
        $users = User::all()->toArray();
    return view('db.data', compact('users'));
         
    }
    public function search(Request $request)
    {
      $datasearch = $request->get('datasearch');
      $users = DB::table('users')->where('author','like', '%' .$datasearch. '%' )->paginate(5);
        return view('db.data',['users' => $users]);
    }
}
