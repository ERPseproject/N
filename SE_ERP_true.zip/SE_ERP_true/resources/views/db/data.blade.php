@extends('layouts.app')
<style media="screen">
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
 
 
    </style>
    <head>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
@section('content')

 
  
 
<br><br><br><br>
<div class="container fluid">
	<div class="row">
  <div class="col-md-6">
  </div>
  <div class="col-md-4" >
    <form action="/datasearch" method="get">
    <div class="input-group">
      <input type="search" name="search" class="form-control ">
      <span class="input-group-prepend">
        <button type="submit" class="btn btn-primary">search</button>

      </span>
    </div>
  </form>
  </div>
        <div class="col-md-12">
         
          <table class="table table-bordered table-striped">
            <tr>
              
              <th>ชือ</th>
              <th>อีเมล</th>
              <th>แก้ไขข้อมูล</th>
              <th>ลบข้อมูล</th>
            </tr>
            @foreach($users as $row)
            <tr>
              <td>{{$row['name']}}</td> 
              <td>{{$row['email']}}</td>
              <td><a href="" class='btn btn-primary'>แก้ไข</a></td>
                                <form method="post" class="delete_form" action="">
                                {{ csrf_field()}}
                                <input type="hidden" name="_method" value="DELETE" />
                                <td><button type="submit" class="btn btn-danger">ลบข้อมูล</button></form> </form></td>
            </tr>
            @endforeach
          </table>
            
        </div>
	</div>
</div>



@endsection
@section('footer')

@endsection
