@extends('layouts.app')
<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
    </style>
@section('content')
<html lang="en">
<head>
  <title>view</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

  <div class="container">
	<div class="row">
        <div class="col-md-9">
    		
            <div id="custom-search-input">

            <!-- <form action="select_std.php" method="get"> -->
              <!-- <select class="form-control" name="mj">
                <option value="./admin" selected="./admin">Human Resources</option>
                <option value="./admin"><a href="./admin">Room</a></option>
                <li><a href="#">JavaScript</a></li>
              </select> -->

              <div class="container">

            <div class="dropdown">
              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Databases
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
                <li><a href="#">Bill</a></li>
                <li><a href="#">Customers</a></li>
                <li><a href="#">Human Resources</a></li>
                <li><a href="#">Machine</a></li>
                <li><a href="#">Project & MOU</a></li>
                <li><a href="#">Research</a></li>
                <li><a href="#">Room</a></li>
              </ul>
            </div>

                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="ป้อนรหัส หรือ ชื่อนิสิต" name="Search">
                    <span class="input-group-btn">
                      <!-- <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="btnGetJson" id="btnGetJson">search</button> -->
                        <button class="btn btn-info btn-lg" type="submit">
                            ...<i class="icon-search"></i>
                        </button>
                    </span>

                </div>
			        </form>
            </div>
        </div>
	</div>
</div>

<div class="container">
  <table class="table table-bordered">
    <br>
    <thead>
      <tr>
        <th>idhr</th>
        <th>name</th>
        <th>pos</th>
        <th>access_lv</th>
        <th>gmail</th>
        <th>address</th>
        <th>pass</th>
        <th>provider_id</th>
      </tr>
    </thead>
    <tbody>
        <?php
          echo App\Http\Controllers\dbController::getData();
        ?>
      </span>
    </tbody>
  </table>
</div>
</body>
</html>
@endsection
@section('footer')

@endsection
