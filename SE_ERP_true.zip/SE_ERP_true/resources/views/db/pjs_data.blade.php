@extends('layouts.app')
<style>
    .main
 {
   /* background-color: #8B0000; */
 padding-top: 5%;
 padding-bottom: 5%;
 }
 
    </style>
    <head>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
@section('content')


  <div class="container-fluid">
  <div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="data">Users</a></li>
    <li><a href="pjs_data"></a></li>
    <li><a href="#">JavaScript</a></li>
  </ul>
</div> 
<br><br><br><br>
	<div class="row">
        <div class="col-md-12">
         
          <table class="table table-bordered table-striped">
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Leader</th>
              <th>Member1</th>
              <th>Member2</th>
              <th>Member3</th>
              <th>Type</th>
            </tr>
            @foreach($pjss as $row)
            <tr>
              <td>{{$row['id']}}</td> 
              <td>{{$row['name']}}</td> 
              <td>{{$row['leader']}}</td>
              <td>{{$row['mem1']}}</td> 
              <td>{{$row['mem2']}}</td> 
              <td>{{$row['mem3']}}</td>
              <td>{{$row['type']}}</td>
            </tr>
            @endforeach
          </table>
            
        </div>
	</div>
</div>



@endsection
@section('footer')

@endsection
