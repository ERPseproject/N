@extends('layouts.app3')


@section('content')
<script type="text/javascript">
    // var msg = '{{Session::get('alert')}}';
    // var exist = '{{Session::has('alert')}}';
    // if (exist) {
    //     alert(msg);
    // }
    function preventBack() {
        window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function() {
        null
    };
</script>


<div class="container text-center" >
<p style="font-size:200px">Welcome</p>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" >
                <div class="card-body">
                    <br>
                    <br>
                    <br>
                    <h2><p>Login Domain @ku.th</p></h2>

                    <a href="{{ route('login.provider', 'google') }}" class="btn btn-primary">{{ __('Google Login') }}</a>

                        @if(\Session::has('alert'))
                            <div class="alert alert-danger">
                                <p>{{ \Session::get('alert') }}</p>
                            </div>
                        @endif


                </div>
            </div>
        </div>
    </div>
</div>
@endsection