@extends('layouts.app3')
<style>
    .main {
        /* background-color: #8B0000; */
        padding-top: 0%;
        padding-bottom: 5%;
    }
</style>
@section('content')
<script type="text/javascript">
 

  

    //////////////////////////////////
    function preventBack() {
        window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function() {
        null
    };
</script>
<!-- main menu -->
<div class="main">

    <div class="container-fluid text-center">
       
        
            <div class="container-fluid text-center">
        <p style="font-size:100px">Welcome</p>
        @if(auth()->user())
        <img src="{{ auth()->user()->avatar }}" alt="avatar" width="150" height="150" style="margin-right: 10px;"><br><br>
        @endif
        <h2>{{ auth()->user()->name }}
            <h2>
                <br><br><br>
                <a href="home" class="btn btn-primary"><h1>เข้าสู่ระบบ</h1></a>
        
       
    </div>

    @endsection