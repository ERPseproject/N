@extends('layouts.Kurupan_app')
@section('content')

    <!--Main Content-->
    
            <div class="container-fluid text-center">
                <!--Side Menu-->
                <div class="row content">
                    <div class="col-sm-2 sidenav">
                        <p><a href="/home">ระบบคุรุภัณฑ์</a></p>  
                    </div>
                    <!--Main Menu-->
                    <div class="col-sm-8">
                            <div class="w3-twothird w3-container">
                                    <form>
                                    <div class="table-responsive">          
                                        <table class="table">
                                        <thead>
                                            <tr>
                                            <th>ชื่อ</th>
                                            <th>รหัส</th>
                                            <th>สถานะการซื้อ</th>
                                            <th>ตำแหน่งที่ตั้ง</th>
                                            <th>วันที่จัดซื้อ</th>
                                            <th>ราคา</th>
                                            <th>ผู้รับผิดชอบ</th>
                                            <th>           
                                                <a href="#">
                                                    <span class="glyphicon glyphicon-picture"></span>
                                                </a>
                                            </th>     
                                            <th>
                                                <a href="#">
                                                    <span class="glyphicon glyphicon-shopping-cart"></span>
                                                </a>
                                            </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                foreach ($items as $item)
                                                {
                                                    ?>
                                                
                                                <tr>
                                                <td>{{ $item->name }}</td>
                                                <td>{{$item->item_id}}</td>
                                                <td>{{$item->stateofbuying}}</td>
                                                <td>{{$item->room}}</td>
                                                <td>{{$item->datetobuy}}</td>
                                                <td>{{$item->price}}</td>
                                                <td>{{$item->responsibleperson}}</td>
                                                <td>
                                                    <a href="#">
                                                        <span class="glyphicon glyphicon-picture"></span>
                                                    </a>
                                                </td>
                                                
                                                <td>
                                                @if($item->datetosell == NULL)
                                            
                                                     <a href="{{ url('/home/sell/' .$item->item_id) }}">
                                                        <span class="glyphicon glyphicon-shopping-cart"></span>
                                                    </a>
                                
                                                @endif
                                                </td>
                                                </tr>
                                                
                                                <?php
                                                    }
                                                ?>
                                                
                                        </tbody>
                                        </table>
                                    </div>
                                    </form>
                                </div>
                    </div>
                    <div class="col-sm-2 sidenav"></div>
                </div>
            </div>
  
    
            @endsection
    @section('footer')

    @endsection
